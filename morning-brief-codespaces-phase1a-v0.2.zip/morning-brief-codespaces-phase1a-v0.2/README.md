# Morning Brief — Phase 1A Connectivity Test v0.2

This is the approved reduced Phase 1A test.

Active test feeds:
1. Times of India — Chennai
2. NDTV — India
3. OneIndia — Chennai
4. PIB — Chennai English
5. PIB — Chennai Tamil

Separate access test:
6. The Indian Express — Chennai

Daily Thanthi and Dinamani remain in the source registry conceptually but are not part of this measured run until a legitimate machine-readable endpoint is established.

Run:

    python -m src.run_check

The output is written to:
`data/connectivity-check-v0.2.json`

No AI, clustering, impact scoring, X, Reddit, personalization or UI is included.
